<div class="jumbotron jumbotron-fluid" style="background-image: url(Imagenes/FondoAgua.jpg);     background-size: 100%; background-repeat: no-repeat;">
  <div class="container">
    <a href="index.php">
      <img src="Imagenes/Logosinfondo.png" class="img-fluid">
    </a>

    <h3>Por un futuro mejor!</h3>
  </div>
</div>
<nav class="navbar navbar-expand-md bg-primary navbar-dark">
  <a class="navbar-brand" href="index.php">ZW</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="somos.php">Quienes somos?</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="aplicacion.php">App</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="clientes.php">Clientes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contacto.php">Contacto</a>
      </li>
    </ul>
  </div>
</nav>