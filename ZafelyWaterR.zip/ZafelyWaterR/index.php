﻿<!DOCTYPE html>
<html>
<?php
  include "head.php"
?>
<body>
<?php
  include "header.php";
  include "inicio.php";
  include "footer.php";
?>
</body>

</html>