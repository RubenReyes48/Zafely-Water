<div class="container">
    <div class="row">
        <div class="col-md">
            <h1 class="mensajeinicio">Espera nuestra aplicación:</h1>
            <img src="Imagenes/Inicio1.jpeg" alt="aplicacion" class="aplicacioninicio">
        </div>
        <div class="col-md">
            <h2 class="proximamente">Proximamente disponible en:</h2>
            <img src="Imagenes/Google.png" class="img-fluis">
            <img src="Imagenes/Apple.png" class="img-fluid">
        </div>
    </div>
    <b>Somos la opción para suplir la demanda del agua que existe en el país con agua de lluvia.</b> </br>
</div>