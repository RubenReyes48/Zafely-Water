<div style="background-color:#00CED1;">
    <a href="aviso/Aviso de privacidad.pdf" download class="copyright">Aviso de privacidad &copy | 2020</a>
</div>